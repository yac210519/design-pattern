// 全局变量
let currentUser = null;
let myCourse = [];

// 页面切换
function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    document.getElementById(pageId).classList.add('active');
}

// 权限校验：未登录禁止访问
function checkLogin(pageId) {
    if (!currentUser) {
        alert('请先登录账号！');
        showPage('login');
        return;
    }
    showPage(pageId);
    // 切换选课/课表时刷新数据
    if(pageId === 'course') renderCourseList();
    if(pageId === 'schedule') renderScheduleList();
}

// 退出登录功能
function logout() {
    currentUser = null;
    myCourse = [];
    document.getElementById('userInfo').innerText = '';
    document.getElementById('logoutBtn').style.display = 'none';
    // 回到首页
    showPage('home');
    alert('已成功退出登录！');
}

// 注册功能
function register() {
    let name = document.getElementById('regName').value.trim();
    let account = document.getElementById('regAccount').value.trim();
    let pwd = document.getElementById('regPwd').value.trim();

    if(!name || !account || !pwd) {
        alert('请填写完整信息！');
        return;
    }
    // 本地存储账号
    let userList = JSON.parse(localStorage.getItem('userList')) || [];
    let exist = userList.find(item => item.account === account);
    if(exist) {
        alert('账号已存在！');
        return;
    }
    userList.push({name, account, pwd});
    localStorage.setItem('userList', JSON.stringify(userList));
    alert('注册成功，请登录！');
    showPage('login');
    // 清空输入
    document.getElementById('regName').value = '';
    document.getElementById('regAccount').value = '';
    document.getElementById('regPwd').value = '';
}

// 登录功能
function login() {
    let account = document.getElementById('loginAccount').value.trim();
    let pwd = document.getElementById('loginPwd').value.trim();
    let userList = JSON.parse(localStorage.getItem('userList')) || [];
    let user = userList.find(item => item.account === account && item.pwd === pwd);

    if(!user) {
        alert('账号或密码错误！');
        return;
    }
    currentUser = user;
    // 显示登录信息 + 显示退出按钮
    document.getElementById('userInfo').innerText = `欢迎你：${user.name}（账号：${user.account}）`;
    document.getElementById('logoutBtn').style.display = 'block';
    // 加载已选课程
    myCourse = JSON.parse(localStorage.getItem('myCourse_'+account)) || [];
    // 登录后跳转到选课大厅
    showPage('course');
    renderCourseList();
}

// 渲染选课大厅
function renderCourseList() {
    let html = '';
    courseList.forEach(course => {
        let isSelected = myCourse.find(item => item.id === course.id);
        html += `
            <div class="course-card">
                <h3>${course.name}</h3>
                <p>课程编号：${course.id}</p>
                <p>授课老师：${course.teacher}</p>
                <p>上课地点：${course.place}</p>
                <p>上课时间：${course.time}</p>
                <p>学分：${course.credit}</p>
                <div class="course-opt">
                    ${isSelected 
                        ? `<button class="opt-btn del" onclick="dropCourse('${course.id}')">退选课程</button>`
                        : `<button class="opt-btn" onclick="selectCourse('${course.id}')">选择课程</button>`
                    }
                </div>
            </div>
        `;
    });
    document.getElementById('courseList').innerHTML = html;
}

// 选课
function selectCourse(cid) {
    let course = courseList.find(item => item.id === cid);
    if(!myCourse.find(item => item.id === cid)) {
        myCourse.push(course);
        localStorage.setItem('myCourse_'+currentUser.account, JSON.stringify(myCourse));
        renderCourseList();
        return true;
    }
    return false;
}

// 退课
function dropCourse(cid) {
    myCourse = myCourse.filter(item => item.id !== cid);
    localStorage.setItem('myCourse_'+currentUser.account, JSON.stringify(myCourse));
    renderCourseList();
}

// 渲染我的课表
function renderScheduleList() {
    if(myCourse.length === 0) {
        document.getElementById('scheduleList').innerHTML = '<div style="text-align:center;padding:50px;color:#666;">你还没有选择任何课程</div>';
        return;
    }
    let html = '';
    myCourse.forEach(course => {
        html += `
            <div class="course-card">
                <h3>${course.name}</h3>
                <p>课程编号：${course.id}</p>
                <p>授课老师：${course.teacher}</p>
                <p>上课地点：${course.place}</p>
                <p>上课时间：${course.time}</p>
                <p>学分：${course.credit}</p>
            </div>
        `;
    });
    document.getElementById('scheduleList').innerHTML = html;
}

// AI助手核心对话逻辑（升级全功能）
function aiChat() {
    let input = document.getElementById('aiInput').value.trim();
    if(!input) return;

    let chatBox = document.getElementById('aiChat');
    // 添加用户消息
    chatBox.innerHTML += `<div class="user-msg">${input}</div>`;

    setTimeout(() => {
        let aiReply = '';

        // 1. 查询已选课程
        if(input.includes('查询已选') || input.includes('我选了哪些') || input.includes('我的课程')) {
            if(myCourse.length === 0) {
                aiReply = '你目前还没有选修任何课程哦，可以去选课大厅选课，也可以让我帮你选课~';
            } else {
                let str = '你当前已选修的课程：<br>';
                myCourse.forEach((c,idx)=>{
                    str += `${idx+1}. ${c.name} | ${c.teacher} | ${c.time}<br>`;
                });
                aiReply = str;
            }
        }
        // 2. AI帮选课
        else if(input.includes('帮我选') || input.includes('选择')) {
            // 提取课程名
            let targetCourse = null;
            for(let c of courseList){
                if(input.includes(c.name)){
                    targetCourse = c;
                    break;
                }
            }
            if(!targetCourse){
                aiReply = '未匹配到对应课程，请输入完整课程名称，例如：帮我选算法设计与分析';
            }else{
                let res = selectCourse(targetCourse.id);
                if(res){
                    aiReply = `已为你成功选修【${targetCourse.name}】！<br>授课老师：${targetCourse.teacher}<br>上课时间：${targetCourse.time}`;
                }else{
                    aiReply = `你已经选修过【${targetCourse.name}】了，无需重复选课~`;
                }
            }
        }
        // 3. AI帮退课
        else if(input.includes('帮我退') || input.includes('退选')) {
            let targetCourse = null;
            for(let c of courseList){
                if(input.includes(c.name)){
                    targetCourse = c;
                    break;
                }
            }
            if(!targetCourse){
                aiReply = '未匹配到对应课程，请输入完整课程名称，例如：帮我退选算法设计与分析';
            }else{
                let has = myCourse.find(item=>item.id === targetCourse.id);
                if(has){
                    dropCourse(targetCourse.id);
                    aiReply = `已为你成功退选【${targetCourse.name}】！`;
                }else{
                    aiReply = `你并未选修【${targetCourse.name}】，无需退课~`;
                }
            }
        }
        // 4. 查询课程详细信息+授课内容
        else {
            let target = courseList.find(item => item.name.includes(input));
            if(target) {
                aiReply = `📚 课程详细信息<br>
课程名称：${target.name}<br>
课程编号：${target.id}<br>
授课老师：${target.teacher}<br>
上课地点：${target.place}<br>
上课时间：${target.time}<br>
学分：${target.credit}<br>
📖 授课内容简介：${target.desc}<br>
你可以对我说：帮我选这门课 / 帮我退选这门课`;
            } else {
                aiReply = '暂时未识别你的指令~<br>可用指令示例：<br>1. 输入课程名了解详情<br>2. 帮我选XXX课程<br>3. 帮我退选XXX课程<br>4. 查询已选课程';
            }
        }

        // 添加AI回复
        chatBox.innerHTML += `<div class="ai-msg">${aiReply}</div>`;
        // 滚动到底部
        chatBox.scrollTop = chatBox.scrollHeight;
    }, 500);

    // 清空输入
    document.getElementById('aiInput').value = '';
}