package Demo2;

public class Meal {
    //food和drink是部件
    private String food;
    private String drink;

    public void setFood(String food) {
        this.food = food;
    }

    public void setDrink(String drink) {
        this.drink = drink;
    }

    public String getFood() {
        return food;
    }
    public String getDrink() {
        return drink;
    }
}
