package Demo13;

import javax.naming.Context;

public interface State {
    void doAction(Context context);
}
