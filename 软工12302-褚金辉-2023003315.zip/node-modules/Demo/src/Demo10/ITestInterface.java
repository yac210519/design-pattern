package Demo10;

public interface ITestInterface {
    public void SendMessage(String mes);
}
