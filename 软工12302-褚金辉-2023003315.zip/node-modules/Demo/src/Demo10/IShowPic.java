package Demo10;

public interface IShowPic {
    void ShowPic(String picname);
}
