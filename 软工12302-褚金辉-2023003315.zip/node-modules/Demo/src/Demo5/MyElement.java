package Demo5;

public abstract class MyElement {
    public abstract void eat();
}
