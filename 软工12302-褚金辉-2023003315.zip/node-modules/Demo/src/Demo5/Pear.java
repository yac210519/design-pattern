package Demo5;

public class Pear extends MyElement
{
    public void eat()
    {
        System.out.println("吃梨子！");
    }
}
