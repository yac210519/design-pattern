package Demo14;

public abstract class Observer {
    protected Subject subject;
    public abstract void update();
}
