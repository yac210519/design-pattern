package Demo14;

public class BinaryObserver extends Observer {
    public BinaryObserver(Subject subject){
        this.subject = subject;
        this.subject.attach(this);
    }

    @Override
    public void update(){
        System.out.println("二进制数：" + Integer.toBinaryString(subject.getState()));
    }
}
