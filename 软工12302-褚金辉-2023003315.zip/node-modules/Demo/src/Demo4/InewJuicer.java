package Demo4;

import Demo3.MyFruit;

public interface InewJuicer {
    public String newPort(MyFruit fruit1,MyFruit fruit2);
}
