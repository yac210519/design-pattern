package Demo3;

public class MyFruit implements Cloneable {
    protected String kind;

    public String Get() {
        return kind;
    }
    public void Set(String kind) {
        this.kind = kind;
    }
    public void Display(){
        System.out.println(kind);
    }

    public Object clone() {
        Object obj = null;
        try {
            obj = super.clone();
        } catch (CloneNotSupportedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return obj;
    }
}