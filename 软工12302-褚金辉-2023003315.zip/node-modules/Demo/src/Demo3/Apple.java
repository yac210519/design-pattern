package Demo3;

public class Apple extends MyFruit {
    public Apple() {
        kind="Apple";
    }
}
