package Demo3;

public class Banana extends MyFruit {
    public Banana() {
        kind="Banana";
    }
}