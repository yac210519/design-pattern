package Demo9;

public interface IShowPic {
    void ShowPic(String picname);
}
