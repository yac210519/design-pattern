package Demo6;

public interface IBirthdayCake {
    void Show();
}
