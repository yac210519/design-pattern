package Demo11;

public interface Command {
    void execute();
}
