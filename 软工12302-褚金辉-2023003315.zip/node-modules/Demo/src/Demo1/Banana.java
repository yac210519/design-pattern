package Demo1;

public class Banana extends Fruit{
    public void eat(){
        System.out.println("eat Banana");
    }
}
