package Demo1;


import Demo3.MyFruit;
import Demo3.Apple;
import Demo3.Banana;
import Demo3.MyFruitStore;
import Demo4.Adapter;
import Demo4.InewJuicer;
import Demo6.Cake;
import Demo6.Fruit;
import Demo6.Cream;
import Demo6.IBirthdayCake;
import Demo8.APiece;
import Demo8.PieceFactory;

import java.util.Random;
import Demo9.CLocalPicShoW;
//import Demo9.CRemoPic;
//import Demo9.IShowPic;
import Demo10.CLoacalPicShow;
import Demo10.IShowPic;
import Demo10.ITestInterface;
import Demo10.CRemoPic;
import Demo10.CTest;

public class ClientClass {

//    public static void main(String[] args){
//        MyFruit fru1 = new Apple();
//        MyFruit fru2 = new Banana();
//        MyFruitStore mfs1 = MyFruitStore.Getfruitstore();
//        mfs1.Add(1,fru1);
//        mfs1.Add(2,fru2);
//        mfs1.Add(3, new Apple());
//        mfs1.Add(4, new Banana());
//        MyFruitStore mfs2 = MyFruitStore.Getfruitstore();
//        InewJuicer newJuicer = new Adapter();
//        System.out.println(newJuicer.newPort(mfs1.Get(1),mfs1.Get(3)));
//
////        MyFruitStore.Add(1,fru1);
////        MyFruitStore.Add(2,fru2);
////        MyFruitStore.Add(3, new Apple());
////        MyFruitStore.Add(4, new Banana());
//
////        MyFruit fru=(MyFruit) mfs2.Get(4);
//
////        MyFruit fru=(MyFruit) MyFruitStore.Get(4);
////        fru.Display();
////        System.out.println("mfs1:" + mfs1.toString());
////        System.out.println("mfs2:" + mfs2.toString());
//    }


//    public static void main(String[] args) {
//        MyFruit fru1=new Apple();
//        MyFruit fru2=(Apple)fru1.clone();
//        fru1.Display();
//        fru2.Display();
//        System.out.println("fru1:"+fru1.hashCode());
//        System.out.println("fru2:"+fru2.hashCode());
//        System.out.println("fru1:"+fru1.toString());
//        System.out.println("fru2:"+fru2.toString());
//        System.out.println(fru1==fru2);
//    }

//    public static void main(String[] args) {
//        // TODO Auto-generated method stub
//        //Factory factor = new BFactory();
//        Factory factor = (Factory)XMLUtil.getBean();
//        Fruit fruit = factor.CreateFruit();
//        //Fruitfruit=factor.CreateFruit("B");
//        //Fruit fruit=(Fruit)XMLUtil.getBean();
//        fruit.eat();
//    }





//    public static void main(String[] args) {
//        IBirthdayCake birthdayCake=new Cake();
//        birthdayCake.Show();
//        Cream cream=new Cream(birthdayCake);
//        cream.PutCream();
//        //cream.Show();
//        Fruit fruit=new Fruit(cream);
//        fruit.PutFruit();
//        fruit.Show();
//    }

    public String factory(String fruitname)
    {
        if(fruitname.equals("Apple"))
            return "Apple";
        if(fruitname.equals("Banana"))
            return "Banana";
        return null;
    }



//    public static void main(String[] args) {
//        Random rm=new Random();
//        PieceFactory pFactory=new PieceFactory();
//        for(int i=0;i<19;i++)
//            for(int j=0;j<19;j++)
//            {
//                APiece p;
//                if(rm.nextInt()%2==0)
//                    p=pFactory.GetPiece("白棋");
//                else
//                    p=pFactory.GetPiece("黑棋");
//                p.Play(rm.nextInt(19), rm.nextInt(19));
//            }
//        System.out.println("总共棋子对象个数是:"+pFactory.GetPieceCount());
//    }



    public static void main(String[] args) {
//        CLocalPicShoW cls=new CLocalPicShoW();
//        cls.ShowPic("我的好图片");
        IShowPic isp= new CRemoPic();
        CLoacalPicShow cpic=new CLoacalPicShow(isp);
        IShowPic localpic=(IShowPic)cpic.getProxyInstance();

//        localpic.ShowPic("AAA");
        ITestInterface ipic=new CTest();
        ITestInterface proxy=(ITestInterface) new CLoacalPicShow(ipic).getProxyInstance();
        proxy.SendMessage("AAA");
    }





}